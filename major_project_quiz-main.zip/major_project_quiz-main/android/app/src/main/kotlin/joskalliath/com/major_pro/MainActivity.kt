package joskalliath.com.major_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
